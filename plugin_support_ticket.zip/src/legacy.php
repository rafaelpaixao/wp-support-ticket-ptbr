<?php
/**
 * This file contains some functions which are depreceated.
 *
 * Please do not use them any further, as they will be removed in a future version of this plugin.
 */

//@codingStandardsIgnoreLine
function sts_get_statusArr() {

	return sts_get_status_arr();
}

//@codingStandardsIgnoreLine
function sts_get_statusClassArr() {

	return sts_get_status_class_arr();
}
